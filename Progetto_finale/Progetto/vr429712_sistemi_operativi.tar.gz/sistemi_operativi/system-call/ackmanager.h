/// @file ackmanager.h
/// @brief Contiene la definizione dell' ackmanager.

#pragma once

void ackmanager();