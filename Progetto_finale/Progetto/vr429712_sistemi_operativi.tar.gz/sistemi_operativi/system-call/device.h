/// @file device.h
/// @brief Contiene la definizione del device.

#pragma once

#include "server.h"
#include "defines.h"

void device(int dev_num);